import java.io.*;
import jakarta.servlet.*;
import jakarta.servlet.http.*;

public class StudentAdmissionServlet extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html");
        PrintWriter out = response.getWriter();

        // Get username and password from the request
        String username = request.getParameter("username");
        String password = request.getParameter("password");

        // Perform authentication (replace this with your authentication logic)
        boolean isAuthenticated = authenticate(username, password);

        // If authentication is successful, show admission preview
        if (isAuthenticated) {
            // Retrieve student admission information from the request
            String name = request.getParameter("name");
            String dob = request.getParameter("dob");
            String address = request.getParameter("address");

            // Display admission preview
            out.println("<html><body>");
            out.println("<h2>Admission Preview</h2>");
            out.println("<p>Name: " + name + "</p>");
            out.println("<p>Date of Birth: " + dob + "</p>");
            out.println("<p>Address: " + address + "</p>");
            out.println("</body></html>");
        } else {
            // If authentication fails, display an error message
            out.println("<html><body>");
            out.println("<h2>Authentication Failed</h2>");
            out.println("<p>Invalid username or password.</p>");
            out.println("</body></html>");
        }

        out.close();
    }

    // Sample authentication method (replace with your own logic)
    private boolean authenticate(String username, String password) {
        // Sample hardcoded credentials for demonstration purposes
        String validUsername = "admin";
        String validPassword = "password";

        // Check if provided username and password match the valid credentials
        return username.equals(validUsername) && password.equals(validPassword);
    }
}
