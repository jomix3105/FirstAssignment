import java.io.*;
import jakarta.servlet.*;
import jakarta.servlet.http.*;

public class ConverterServlet extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html");
        PrintWriter out = response.getWriter();

        // Retrieve the input number
        int number = Integer.parseInt(request.getParameter("number"));

        // Convert the number to binary, octal, and hexadecimal
        String binary = Integer.toBinaryString(number);
        String octal = Integer.toOctalString(number);
        String hex = Integer.toHexString(number);

        // Output the results
        out.println("<html><body>");
        out.println("<h2>Number Conversion Results</h2>");
        out.println("<p>Decimal: " + number + "</p>");
        out.println("<p>Binary: " + binary + "</p>");
        out.println("<p>Octal: " + octal + "</p>");
        out.println("<p>Hexadecimal: " + hex + "</p>");
        out.println("</body></html>");

        out.close();
    }
}
